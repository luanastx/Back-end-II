package com.sistema.backend2;

public class entity {

}
