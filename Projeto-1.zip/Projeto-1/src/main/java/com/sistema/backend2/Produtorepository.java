package com.sistema.backend2;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository
public class Produtorepository {
	public List<Produto>findAllProdutos(){
		List<Produto> list = new ArrayList<>();
		list.add(new Produto(1, "notebook", 5000.0));
		list.add(new Produto(2,"Iphone", 1900.0));
		
		return list;
		
	}

}
